<footer>
	<div class="container">
		<div class="row">
<p>&copy; 2013 StartBBS Inc, Some rights reserved.</p>
<p>Powered by<a href="<?php echo $this->config->item('sys_url');?>" class="text-muted" target="_blank"><?php echo $this->config->item('sys_name');?></a>
<?php echo $this->config->item('sys_version');?>  <?php echo $settings['site_stats']?>-
<p>页面执行时间:  {elapsed_time}s</p>
		</div>
	</div>
</footer>
<script src="http://www.blacktie.co/demo/pratt/assets/js/smoothscroll.js"></script>
<script src="http://www.blacktie.co/demo/pratt/assets/js/bootstrap.js"></script>
<!--[if lt IE 9]>
<script src="http://cdn.bootcss.com/html5shiv/3.7.0/html5shiv.min.js"></script>
<script src="http://cdn.bootcss.com/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->
</body></html>