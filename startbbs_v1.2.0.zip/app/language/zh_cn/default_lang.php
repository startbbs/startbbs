<?php

$lang['front_home'] = "首页";


/* End of file front_lang.php */
/* Location: ./system/language/english/front_lang.php */