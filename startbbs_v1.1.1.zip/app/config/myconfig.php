<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config = array (
  'site_name' => 'StartBBS- 起点开源论坛-烧饼bbs',
  'index_page' => 'index.php',
  'show_captcha' => 'on',
  'show_editor' => 'on',
  'basic_folder' => '',
  'version' => 'V1.1.1',
  'themes' => 'default',
  'auto_tag' => 'on',
);
