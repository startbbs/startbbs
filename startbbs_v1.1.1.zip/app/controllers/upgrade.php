<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
#doc
#	classname:	upgrade
#	scope:		PUBLIC
#	StartBBS起点轻量开源社区系统
#	author :doudou QQ:858292510 startbbs@126.com
#	Copyright (c) 2013 http://www.startbbs.com All rights reserved.
#/doc

class Upgrade extends Other_Controller
{
	function __construct ()
	{
		parent::__construct();
		$this->load->library('myclass');

	}
	public function index ()
	{
		$data['old_version'] = $this->config->item('version');
		$data['new_version'] = 'V1.1.1';
		if($data['new_version']==$data['old_version']){
			$data['msg'] = '您的版本为最新版，无需升级';
		} else{
			$data['msg'] = '开始升级';
		}
		$data['log'] = '';
		$this->load->view('upgrade',$data);
	}

	public function do_upgrade ()
	{
		$sql1="DROP TABLE IF EXISTS `{$this->db->dbprefix}groups`;";
		if($this->db->query($sql1)){
			$data['msg1'] = '删除旧的groups表';
		}
		$sql2="CREATE TABLE IF NOT EXISTS `{$this->db->dbprefix}user_groups` (
  `gid` int(11) NOT NULL AUTO_INCREMENT,
  `group_type` tinyint(3) NOT NULL DEFAULT '0',
  `group_name` varchar(50) DEFAULT NULL,
  `usernum` int(11) NOT NULL,
  PRIMARY KEY (`gid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4;";
		if($this->db->query($sql2)){
			$data['msg2'] = '增加新的group表成功';
		}
		$sql3="INSERT INTO `{$this->db->dbprefix}user_groups` (`gid`, `group_type`, `group_name`, `usernum`) VALUES
(1, 0, '管理员', 1),
(2, 1, '版主', 0),
(3, 2, '普通会员', 0);";
		if($this->db->query($sql3)){
			$data['msg3'] = '更新group数据成功';
		}
		$sql4="ALTER TABLE  `{$this->db->dbprefix}users` CHANGE  `gid`  `group_type` TINYINT( 3 ) NOT NULL DEFAULT  '0';";
		if($this->db->query($sql4)){
			$data['msg4'] = '修改user表中的gid字段';
		}
		$sql5="UPDATE  `{$this->db->database}`.`{$this->db->dbprefix}users` SET  `group_type` =  '2' WHERE `{$this->db->dbprefix}users`.`group_type` =1;";
		if($this->db->query($sql5)){
			$data['msg5'] = '更新group_type数据成功';
		}
		$sql6="ALTER TABLE  `{$this->db->dbprefix}users` ADD  `gid` TINYINT( 3 ) NOT NULL DEFAULT  '3' AFTER  `group_type`;";
		if($this->db->query($sql6)){
			$data['msg6'] = '增加user表中gid成功';
		}
		$sql7="UPDATE  `{$this->db->database}`.`{$this->db->dbprefix}users` SET  `gid` =  '1' WHERE  `{$this->db->dbprefix}users`.`group_type` =0;";
		if($this->db->query($sql7)){
			$data['msg7'] = '更新user表中的gid数据';
		}
		$sql8="ALTER TABLE  `{$this->db->dbprefix}categories` ADD  `master` VARCHAR( 100 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL AFTER  `ico`;";
		if($this->db->query($sql8)){
			$data['msg8'] = '增加版主字段master';
		}
		$sql9="ALTER TABLE  `{$this->db->dbprefix}forums` ADD  `is_hidden` TINYINT( 1 ) NOT NULL DEFAULT  '0' AFTER  `is_top`;";
		if($this->db->query($sql9)){
			$data['msg9'] = '增加审核贴子字段is_hidden';
		}
		$sql10="ALTER TABLE  `{$this->db->dbprefix}categories` ADD  `permit` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL AFTER  `master`;";
		if($this->db->query($sql10)){
			$data['msg10'] = '节点增加权限字段';
		}
		
		if($this->config->update('myconfig','version','V1.1.1')){
			$data['msg_v'] = '版本号更新成功';
		}
		
		$data['finish'] = '升级完成...';
		$data['error'] = '升级失败';
		exit(json_encode($data));		
	}

	function deldir($dir) { 
	//先删除目录下的文件： 
	$dh=opendir($dir); 
	while ($file=readdir($dh)) { 
	if($file!="." && $file!="..") { 
	$fullpath=$dir."/".$file; 
	if(!is_dir($fullpath)) { 
	unlink($fullpath); 
	} else { 
	deldir($fullpath); 
	} 
	} 
	} 
	closedir($dh); 
	//删除当前文件夹： 
	if(rmdir($dir)) { 
	return true; 
	} else { 
	return false; 
	} 
	}

	//function write_config($data)
	//{
	//	$filepath=FCPATH.'/app/config/myconfig.php';
	//	$file=read_file($filepath);
	//	$newdata=',\n'.$data.',\n);';
	//	$newfile=str_replace(',\n);',$newdata,$file);
	//	if(write_file($filepath,$newfile)){
	//		return true;
	//	}
		
	//}
}