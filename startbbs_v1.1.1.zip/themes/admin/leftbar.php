<div class='span2'>
<div class='box fix_cell'>
<div class='cell'>
<strong class='gray'>社区管理</strong>
</div>
<div class='cell'>
Dashboard
&nbsp;
<a href="<?php echo site_url('admin/login');?>" class="current_item">运行状态</a>
</div>
<div class='cell'>
Settings
&nbsp;
<a href="<?php echo site_url('admin/site_settings');?>">基本设置</a>
</div>
<!--<div class='cell'>
<img align="absmiddle" alt="Palette" src="/assets/admin/palette-29b0e5cd214d642c9ea3c0ae4f6a3019.png" valign="middle" />
&nbsp;
<a href="/admin/appearance">外观</a>
</div>-->
<div class='cell'>
Users
&nbsp;
<a href="<?php echo site_url('admin/users/index');?>">用户</a>
</div>
<div class='cell'>
Nodes
&nbsp;
<a href="<?php echo site_url('admin/nodes');?>">版块结点</a>
</div>
<div class='cell'>
Topics
&nbsp;
<a href="<?php echo site_url('admin/topics');?>">讨论话题</a>
</div>
<div class='cell'>
Links
&nbsp;
<a href="<?php echo site_url('admin/links');?>">链接</a>
</div>
<div class='cell'>
Page
&nbsp;
<a href="<?php echo site_url('admin/page');?>">单页面</a>
</div>
<div class='cell'>
DbAdmin
&nbsp;
<a href="<?php echo site_url('admin/db_admin/index');?>">数据库管理</a>
</div>
<!--<div class='cell'>
<img align="absmiddle" alt="Pages" src="/assets/admin/pages-35f97f71adb2980521de5cb0e3c65c14.png" valign="middle" />
&nbsp;
<a href="/admin/pages">页面</a>
</div>
<div class='cell'>
<img align="absmiddle" alt="Ads" src="/assets/admin/ads-cdf555d066a78e7df8ab809ab1efa3b1.png" valign="middle" />
&nbsp;
<a href="/admin/advertisements">广告位</a>
</div>
<div class='cell'>
<img align="absmiddle" alt="Cloud" src="/assets/admin/cloud-3a4d7676e126e7eb5690d55058e9f07f.png" valign="middle" />
&nbsp;
<a href="/admin/cloud_files">文件上传</a>
</div>
<div class='cell'>
<img align="absmiddle" alt="Reward_history" src="/assets/admin/reward_history-4d4dab9405900fa22b1654192aca31cb.png" valign="middle" />
&nbsp;
<a href="/admin/rewards">奖励记录</a>
</div>
<div class='cell'>
<script language="javascript" type="text/javascript" src="http://js.users.51.la/15282046.js"></script>
</div>
-->
<div class='cell'>
Startbbs
&nbsp;
<a href="http://www.startbbs.com">访问官方</a>
</div>

</div>

</div>