<div class='box'>
<div class='inner'>
<span style='font-weight: bold; font-size: 10px; color: #e2e2e2;'>Promotion</span>
<div class='sep10'></div>
<span style='font-size: 12px; color: #666;'>
<strong style='color: #000;'>
<a href="https://me.alipay.com/startbbs" class="black track_event" data-action="click" data-category="ad" data-label="赞助 StartBBS 开发" target="_blank">广告位:</a>
</strong>
</span>
<div class='sep3'></div>
<span style='font-size: 12px;'><a href="http://www.startbbs.com">StartBBS</a>-一款轻量简单易用的开源社区程序</span>

</div>
</div>

<!--<div class='box'>
<div class='inner'>
<span style='font-weight: bold; font-size: 10px; color: #e2e2e2;'>Promotion</span>
<div class='sep10'></div>
<a href="https://www.upyun.com/?md=startbbs" class="track_event" data-action="click" data-category="ad" data-label="又拍云存储" target="_blank"><img alt="5e086e2ab89" border="0" height="90" src="/uploads/advertisement_banner/4/4/5e086e2ab89.png" width="120" />
</a><div class='sep5'></div>
<span style='font-size: 11px; color: #666;'>
<strong style='color: #000;'>
<a href="https://www.upyun.com/?md=startbbs" class="black track_event" data-action="click" data-category="ad" data-label="又拍云存储" target="_blank">又拍云存储</a>
</strong>
</span>
<div class='sep3'></div>
<span style='font-size: 12px;'><?=$settings['site_name']?> 官方推荐的国内云存储平台，好用又实惠，轻松解决社区附件存储难题。
</span>
</div>
</div>-->