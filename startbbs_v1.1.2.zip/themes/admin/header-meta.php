 <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<meta content='width=device-width, initial-scale=1.0' name='viewport'>
<link href="/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
<link href="/topics.atom" rel="alternate" title="ATOM" type="application/atom+xml" />
<link href='http://www.startbbs.com' rel='canonical'>
<meta content="authenticity_token" name="csrf-param" />
<meta content="suTN1ExyGAX0WFd5f9EbmfgGT0VH6+QlmmtHwG2u16I=" name="csrf-token" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<link href="<?php echo base_url('static/common/css/mystyle.css');?>" media="screen" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo base_url('static/common/js/jquery-1.9.1.min.js');?>"></script>
<script src="<?php echo base_url('static/common/js/global.js');?>" type="text/javascript"></script>
<link href="/apple-touch-icon.png" rel="apple-touch-icon" />
<script type="text/javascript">
var baseurl='<?php echo base_url()?>';
var siteurl='<?php echo site_url()?>';
</script>