<div id='footer'>
<div class='container' id='footer-main'>
<ul class='page-links'>
<!--<li><a href="/page/about" class="dark nav">StartBBS 简介</a></li>
<li class='snow'>·</li>
<li><a href="/page/support" class="dark nav">技术支持</a></li>-->
</ul>
<div class='copywrite'>
<div class="fr"> <!--<a href="" target="_blank"><img src="" border="0" alt="Linode" width="120"></a>--></div>
<p>&copy; 2013 StartBBS Inc, Some rights reserved.</p>
</div>
<small class='muted'>
Powered by
<a href="http://www.startbbs.com" class="muted" target="_blank"><?=$settings['site_name']?></a>
<?=$this->config->item('version');?>  <?=$settings['site_stats']?>-
<p>页面执行时间:  {elapsed_time}s</p>
</small>
</div>
</div>
</body></html>