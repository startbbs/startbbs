<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config = array (
  'storage_set' => 'local',
  'accesskey' => '',
  'secretkey' => '',
  'bucket' => '',
  'file_domain' => '',
);