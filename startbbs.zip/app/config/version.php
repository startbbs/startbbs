<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config = array (
  'sys_name' => 'StartBBS',
  'sys_url' => 'http://www.startbbs.com',
  'sys_version' => 'V1.2.0',
  'sys_update' => '20141210',
  'sys_author' => 'QQ858292510',
);
