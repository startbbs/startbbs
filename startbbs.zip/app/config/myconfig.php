<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config = array (
  'site_name' => 'StartBBS- 起点开源论坛-烧饼bbs',
  'index_page' => 'index.php',
  'show_captcha' => 'on',
  'site_close' => 'on',
  'site_close_msg' => '网站升级中，暂时关闭。       ',
  'basic_folder' => '',
  'version' => false,
  'static' => 'white',
  'themes' => 'default',
  'logo' => 'Start<span class=\'green\'>BBS</span>',
  'auto_tag' => 'on',
  'encryption_key' => 'd6c7ef5a51eb5eed3443b3275fb891d8',
);
