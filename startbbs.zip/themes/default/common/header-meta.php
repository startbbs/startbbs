<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<link href='http://www.startbbs.com' rel='canonical'>
<link href="<?php echo base_url('static/common/css/bootstrap.min.css');?>" media="screen" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url('static/common/css/style.css');?>" media="screen" rel="stylesheet" type="text/css" />
<script type="text/javascript">
var baseurl='<?php echo base_url()?>';
var siteurl='<?php echo site_url()?>';
var sitedomain='<?php echo get_domain()?>';
</script>
<script type="text/javascript" src="<?php echo base_url('static/common/js/jquery-1.10.2.min.js');?>"></script>
<!--[if lt IE 9]>
<script src="http://cdn.bootcss.com/html5shiv/3.7.0/html5shiv.min.js"></script>
<script src="http://cdn.bootcss.com/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->