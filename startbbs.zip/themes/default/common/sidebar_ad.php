<div class="panel panel-default">
    <div class="panel-heading">
        <h3 class="panel-title">广告位</h3>
    </div>
    <div class="panel-body">
        <a href="http://www.startbbs.com">StartBBS</a>-一款轻量简单易用的开源社区程序
    </div>
</div>